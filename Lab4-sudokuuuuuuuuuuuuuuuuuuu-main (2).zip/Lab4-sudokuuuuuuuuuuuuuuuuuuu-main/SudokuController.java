public class SudokuController {

    public static void main(String[] args) {
        System.out.println("controller");
    }
}
