package SudokuModel.SudokuModel;

public class WrongUserInputException {
}
