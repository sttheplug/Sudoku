package SudokuModel.SudokuModel;

public class SudokuUtilities {

    public void generateSudokuMatrix()
    {

    }
}
