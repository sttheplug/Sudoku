package SudokuModel.SudokuModel;

public class SudokuSquare {
}
