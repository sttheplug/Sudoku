package SudokuModel.SudokuModel;

public class CalculateSudokuPoints {
}
