package SudokuModel;

public class SudkoLogic {

    public static void main(String[] args) {
        System.out.println("Logic");
    }
}
