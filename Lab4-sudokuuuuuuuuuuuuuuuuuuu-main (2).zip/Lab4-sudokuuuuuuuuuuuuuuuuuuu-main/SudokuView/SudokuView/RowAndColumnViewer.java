package SudokuView.SudokuView;

public class RowAndColumnViewer {

    //view för en rad och kolumn som i spelet på webben,
}
