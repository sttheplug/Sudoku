package SudokuView.SudokuView;

public class SudokuViewer {

    public static void main(String[] args) {
        System.out.println("viewer");

        //vy för "Hela spelet"
    }
}
